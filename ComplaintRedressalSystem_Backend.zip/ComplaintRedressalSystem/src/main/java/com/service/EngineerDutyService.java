package com.service;

import com.model.EngineerDuty;

public interface EngineerDutyService {
	void saveEngineerDuty (EngineerDuty engineerDuty);

}
