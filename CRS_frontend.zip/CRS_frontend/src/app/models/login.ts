// it is use to map to json data from backend technologies. 
export interface Login {
    emailid:string;
    password:string;
    typeOfUser:string;
}
